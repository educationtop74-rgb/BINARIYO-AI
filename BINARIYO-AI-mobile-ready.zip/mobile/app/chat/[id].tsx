import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import { fetch } from "expo/fetch";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import * as Clipboard from "expo-clipboard";

import { PERSONAS } from "@/constants/personas";
import { useColors } from "@/hooks/useColors";
import { useConversation } from "@/hooks/useConversations";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const convId = Number(id);
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const inputRef = useRef<TextInput>(null);

  const { conversation, isLoading } = useConversation(convId);

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [streamingId, setStreamingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [convTitle, setConvTitle] = useState<string | null>(null);

  const handleCopy = async (msgId: string, text: string) => {
    await Clipboard.setStringAsync(text);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setCopiedId(msgId);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const persona = PERSONAS.find((p) => p.name === conversation?.personaName);
  const accentColor = persona?.accentColor ?? colors.primary;

  useEffect(() => {
    if (conversation?.messages) {
      setMessages(
        conversation.messages.map((m) => ({
          id: String(m.id),
          role: m.role as "user" | "assistant",
          content: m.content,
        }))
      );
    }
  }, [conversation?.messages]);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const sendMessage = useCallback(async () => {
    const text = inputText.trim();
    if (!text || streaming) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setInputText("");

    const userMsgId = `${Date.now()}-u`;
    const aiMsgId = `${Date.now()}-a`;

    setMessages((prev) => [
      { id: aiMsgId, role: "assistant", content: "" },
      { id: userMsgId, role: "user", content: text },
      ...prev,
    ]);

    setStreaming(true);
    setStreamingId(aiMsgId);

    try {
      const response = await fetch(
        `https://chat-bot-ai--educationtop74.replit.app/api/openai/conversations/${convId}/messages`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: text }),
        }
      );

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (!jsonStr) continue;
          try {
            const parsed = JSON.parse(jsonStr) as {
              content?: string;
              done?: boolean;
              autoTitle?: string;
            };
            if (parsed.content) {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === aiMsgId
                    ? { ...m, content: m.content + parsed.content }
                    : m
                )
              );
            }
            if (parsed.autoTitle) {
              setConvTitle(parsed.autoTitle);
            }
          } catch {}
        }
      }
    } catch {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === aiMsgId
            ? {
                ...m,
                content: "Sorry, something went wrong. Please try again.",
              }
            : m
        )
      );
    } finally {
      setStreaming(false);
      setStreamingId(null);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [inputText, streaming, convId]);

  const regenerate = useCallback(async () => {
    if (streaming) return;

    const lastAI = messages.find((m) => m.role === "assistant");
    if (!lastAI) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const regenId = `${Date.now()}-regen`;
    setMessages((prev) =>
      prev.map((m) => (m.id === lastAI.id ? { ...m, id: regenId, content: "" } : m))
    );
    setStreaming(true);
    setStreamingId(regenId);

    try {
      const response = await fetch(
        `https://chat-bot-ai--educationtop74.replit.app/api/openai/conversations/${convId}/regenerate`,
        { method: "POST", headers: { "Content-Type": "application/json" } }
      );
      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (!jsonStr) continue;
          try {
            const parsed = JSON.parse(jsonStr) as { content?: string; done?: boolean };
            if (parsed.content) {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === regenId ? { ...m, content: m.content + parsed.content } : m
                )
              );
            }
          } catch {}
        }
      }
    } catch {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === regenId ? { ...m, content: "Sorry, something went wrong." } : m
        )
      );
    } finally {
      setStreaming(false);
      setStreamingId(null);
    }
  }, [streaming, messages, convId]);

  const styles = makeStyles(colors, topPad, bottomPad);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable style={styles.headerBtn} onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]} numberOfLines={1}>
            {convTitle ?? conversation?.title ?? "Chat"}
          </Text>
          {persona && (
            <View style={[styles.personaBadge, { backgroundColor: accentColor + "22" }]}>
              <Text style={styles.personaBadgeEmoji}>{persona.emoji}</Text>
              <Text style={[styles.personaBadgeLabel, { color: accentColor }]}>
                {persona.name}
              </Text>
            </View>
          )}
        </View>
        <View style={styles.headerBtn} />
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        {isLoading && messages.length === 0 ? (
          <View style={styles.center}>
            <ActivityIndicator color={accentColor} size="large" />
          </View>
        ) : messages.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>{persona?.emoji ?? "🤖"}</Text>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              {persona?.name ?? "Assistant"}
            </Text>
            <Text style={[styles.emptyTagline, { color: colors.mutedForeground }]}>
              {persona?.tagline ?? "Ready to help"}
            </Text>
            {persona?.starters && (
              <View style={styles.starterGrid}>
                {persona.starters.map((starter, i) => (
                  <Pressable
                    key={i}
                    style={({ pressed }) => [
                      styles.starterChip,
                      {
                        backgroundColor: pressed
                          ? accentColor + "22"
                          : colors.card,
                        borderColor: accentColor + "44",
                      },
                    ]}
                    onPress={() => {
                      setInputText(starter);
                      setTimeout(() => inputRef.current?.focus(), 50);
                    }}
                  >
                    <Text
                      style={[styles.starterText, { color: colors.foreground }]}
                      numberOfLines={2}
                    >
                      {starter}
                    </Text>
                  </Pressable>
                ))}
              </View>
            )}
          </View>
        ) : (
          <FlatList
            data={messages}
            keyExtractor={(m) => m.id}
            inverted
            contentContainerStyle={styles.messageList}
            keyboardDismissMode="interactive"
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => {
              const isUser = item.role === "user";
              const isStreamingThis = item.id === streamingId;
              const isCopied = item.id === copiedId;
              const canCopy = !isStreamingThis && item.content.length > 0;
              // FlatList is inverted — index 0 is the most recent message
              const isLastAI = !isUser && index === 0 && !streaming;
              return (
                <View>
                  <View
                    style={[
                      styles.msgRow,
                      isUser ? styles.msgRowUser : styles.msgRowAI,
                    ]}
                  >
                    {!isUser && (
                      <View
                        style={[
                          styles.avatar,
                          { backgroundColor: accentColor + "22" },
                        ]}
                      >
                        <Text style={styles.avatarEmoji}>
                          {persona?.emoji ?? "🤖"}
                        </Text>
                      </View>
                    )}
                    <Pressable
                      onLongPress={() =>
                        canCopy && handleCopy(item.id, item.content)
                      }
                      delayLongPress={400}
                      style={[
                        styles.bubble,
                        isUser
                          ? [styles.bubbleUser, { backgroundColor: accentColor }]
                          : [
                              styles.bubbleAI,
                              {
                                backgroundColor: colors.aiBubble,
                                borderColor: colors.border,
                              },
                            ],
                      ]}
                    >
                      {isStreamingThis && item.content === "" ? (
                        <ActivityIndicator
                          color={colors.mutedForeground}
                          size="small"
                        />
                      ) : isCopied ? (
                        <Text
                          style={[
                            styles.bubbleText,
                            styles.copiedText,
                            { color: isUser ? "#fff" : colors.aiBubbleText },
                          ]}
                        >
                          ✓ Copied!
                        </Text>
                      ) : (
                        <Text
                          style={[
                            styles.bubbleText,
                            { color: isUser ? "#fff" : colors.aiBubbleText },
                          ]}
                        >
                          {item.content}
                        </Text>
                      )}
                    </Pressable>
                  </View>
                  {isLastAI && (
                    <Pressable
                      onPress={regenerate}
                      style={({ pressed }) => [
                        styles.regenBtn,
                        { opacity: pressed ? 0.6 : 1 },
                      ]}
                    >
                      <Feather
                        name="refresh-cw"
                        size={12}
                        color={colors.mutedForeground}
                      />
                      <Text style={[styles.regenText, { color: colors.mutedForeground }]}>
                        Regenerate
                      </Text>
                    </Pressable>
                  )}
                </View>
              );
            }}
          />
        )}

        <View
          style={[
            styles.inputBar,
            {
              backgroundColor: colors.card,
              borderTopColor: colors.border,
              paddingBottom: bottomPad + 8,
            },
          ]}
        >
          <TextInput
            ref={inputRef}
            style={[
              styles.input,
              {
                backgroundColor: colors.muted,
                color: colors.foreground,
                borderColor: colors.border,
              },
            ]}
            placeholder="Message..."
            placeholderTextColor={colors.mutedForeground}
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={4000}
            returnKeyType="send"
            blurOnSubmit={false}
            onSubmitEditing={sendMessage}
          />
          <Pressable
            style={({ pressed }) => [
              styles.sendBtn,
              {
                backgroundColor:
                  inputText.trim() && !streaming ? accentColor : colors.muted,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            onPress={sendMessage}
            disabled={!inputText.trim() || streaming}
          >
            <Feather
              name="send"
              size={18}
              color={
                inputText.trim() && !streaming ? "#fff" : colors.mutedForeground
              }
            />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

function makeStyles(
  colors: ReturnType<typeof useColors>,
  topPad: number,
  _bottomPad: number
) {
  return StyleSheet.create({
    container: { flex: 1 },
    header: {
      flexDirection: "row",
      alignItems: "center",
      paddingTop: topPad + 8,
      paddingBottom: 10,
      paddingHorizontal: 12,
      borderBottomWidth: 1,
      gap: 4,
    },
    headerBtn: {
      width: 40,
      height: 40,
      alignItems: "center",
      justifyContent: "center",
    },
    headerCenter: {
      flex: 1,
      alignItems: "center",
      gap: 4,
    },
    headerTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 16,
      textAlign: "center",
    },
    personaBadge: {
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 8,
      gap: 4,
    },
    personaBadgeEmoji: { fontSize: 11 },
    personaBadgeLabel: {
      fontFamily: "Inter_500Medium",
      fontSize: 11,
    },
    center: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      paddingHorizontal: 32,
    },
    emptyState: {
      flex: 1,
      alignItems: "center",
      paddingTop: 48,
      paddingHorizontal: 20,
      gap: 6,
    },
    emptyEmoji: { fontSize: 52, marginBottom: 4 },
    emptyTitle: {
      fontFamily: "Inter_700Bold",
      fontSize: 20,
    },
    emptyTagline: {
      fontFamily: "Inter_400Regular",
      fontSize: 14,
      marginBottom: 12,
    },
    starterGrid: {
      width: "100%",
      gap: 10,
      marginTop: 8,
    },
    starterChip: {
      borderRadius: 14,
      borderWidth: 1,
      paddingVertical: 12,
      paddingHorizontal: 16,
    },
    starterText: {
      fontFamily: "Inter_500Medium",
      fontSize: 14,
      lineHeight: 20,
    },
    regenBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      alignSelf: "flex-start",
      marginLeft: 52,
      marginTop: 4,
      marginBottom: 8,
      paddingVertical: 4,
      paddingHorizontal: 10,
      borderRadius: 8,
    },
    regenText: {
      fontFamily: "Inter_500Medium",
      fontSize: 12,
    },
    messageList: {
      paddingHorizontal: 16,
      paddingTop: 12,
      paddingBottom: 8,
    },
    msgRow: {
      flexDirection: "row",
      marginBottom: 12,
      alignItems: "flex-end",
    },
    msgRowUser: { justifyContent: "flex-end" },
    msgRowAI: { justifyContent: "flex-start" },
    avatar: {
      width: 30,
      height: 30,
      borderRadius: 10,
      alignItems: "center",
      justifyContent: "center",
      marginRight: 8,
      marginBottom: 2,
    },
    avatarEmoji: { fontSize: 16 },
    bubble: {
      maxWidth: "78%",
      borderRadius: 18,
      paddingHorizontal: 14,
      paddingVertical: 10,
    },
    bubbleUser: { borderBottomRightRadius: 4 },
    bubbleAI: {
      borderBottomLeftRadius: 4,
      borderWidth: 1,
    },
    bubbleText: {
      fontFamily: "Inter_400Regular",
      fontSize: 15,
      lineHeight: 22,
    },
    inputBar: {
      flexDirection: "row",
      alignItems: "flex-end",
      paddingHorizontal: 12,
      paddingTop: 10,
      borderTopWidth: 1,
      gap: 8,
    },
    input: {
      flex: 1,
      minHeight: 44,
      maxHeight: 120,
      borderRadius: 14,
      paddingHorizontal: 14,
      paddingVertical: 10,
      fontFamily: "Inter_400Regular",
      fontSize: 15,
      borderWidth: 1,
    },
    sendBtn: {
      width: 44,
      height: 44,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
    },
    copiedText: {
      fontFamily: "Inter_500Medium",
    },
  });
}
