import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { PersonaPicker } from "@/components/PersonaPicker";
import { PERSONAS, type Persona } from "@/constants/personas";
import { useTheme } from "@/context/ThemeContext";
import { useColors } from "@/hooks/useColors";
import { useConversations } from "@/hooks/useConversations";

export default function HomeScreen() {
  const colors = useColors();
  const { resolved, toggle } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { conversations, isLoading, createConversation, deleteConversation } =
    useConversations();
  const [newTitle, setNewTitle] = useState("");
  const [creating, setCreating] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<Persona>(PERSONAS[0]!);
  const [pickerVisible, setPickerVisible] = useState(false);
  const [search, setSearch] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const filtered = conversations.filter((c) =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  const handleNew = async () => {
    const title = newTitle.trim() || `${selectedPersona.name} Chat`;
    setCreating(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      const conv = await createConversation({
        title,
        systemPrompt: selectedPersona.systemPrompt,
        personaName: selectedPersona.name,
      });
      setNewTitle("");
      router.push(`/chat/${conv.id}`);
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = (id: number, title: string) => {
    Alert.alert("Delete conversation", `Delete "${title}"?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          await deleteConversation(id);
        },
      },
    ]);
  };

  const styles = makeStyles(colors, topPad, bottomPad);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.headerTitle}>Chats</Text>
            <Text style={styles.headerSub}>Powered by Gemini 2.5 Flash</Text>
          </View>
          <Pressable
            onPress={toggle}
            style={({ pressed }) => [
              styles.themeBtn,
              { backgroundColor: colors.muted, opacity: pressed ? 0.7 : 1 },
            ]}
            hitSlop={8}
          >
            <Feather
              name={resolved === "dark" ? "sun" : "moon"}
              size={18}
              color={colors.foreground}
            />
          </Pressable>
        </View>
      </View>

      {conversations.length > 0 && (
        <View style={[styles.searchRow, { paddingHorizontal: 16, marginBottom: 8 }]}>
          <View style={[styles.searchBox, { backgroundColor: colors.muted, borderColor: colors.border }]}>
            <Feather name="search" size={16} color={colors.mutedForeground} style={{ marginRight: 8 }} />
            <TextInput
              style={[styles.searchInput, { color: colors.foreground }]}
              placeholder="Search conversations..."
              placeholderTextColor={colors.mutedForeground}
              value={search}
              onChangeText={setSearch}
              returnKeyType="search"
              clearButtonMode="while-editing"
            />
          </View>
        </View>
      )}

      {isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : conversations.length === 0 ? (
        <View style={styles.center}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
            <Feather name="message-circle" size={32} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            No conversations yet
          </Text>
          <Text style={[styles.emptySub, { color: colors.mutedForeground }]}>
            Pick a persona and start chatting
          </Text>
        </View>
      ) : filtered.length === 0 ? (
        <View style={styles.center}>
          <Feather name="search" size={32} color={colors.mutedForeground} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            No results
          </Text>
          <Text style={[styles.emptySub, { color: colors.mutedForeground }]}>
            No chats match "{search}"
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(c) => String(c.id)}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <Pressable
              style={({ pressed }) => [
                styles.card,
                { backgroundColor: colors.card, opacity: pressed ? 0.85 : 1 },
              ]}
              onPress={() => router.push(`/chat/${item.id}`)}
            >
              <View style={styles.cardLeft}>
                <View
                  style={[
                    styles.cardIcon,
                    { backgroundColor: colors.secondary },
                  ]}
                >
                  <Text style={styles.cardEmoji}>
                    {PERSONAS.find((p) => p.name === item.personaName)?.emoji ??
                      "🤖"}
                  </Text>
                </View>
                <View style={styles.cardText}>
                  <Text
                    style={[styles.cardTitle, { color: colors.foreground }]}
                    numberOfLines={1}
                  >
                    {item.title}
                  </Text>
                  <Text
                    style={[
                      styles.cardMeta,
                      { color: colors.mutedForeground },
                    ]}
                  >
                    {item.personaName} ·{" "}
                    {new Date(item.createdAt).toLocaleDateString()}
                  </Text>
                </View>
              </View>
              <Pressable
                onPress={() => handleDelete(item.id, item.title)}
                hitSlop={12}
                style={styles.deleteBtn}
              >
                <Feather
                  name="trash-2"
                  size={16}
                  color={colors.mutedForeground}
                />
              </Pressable>
            </Pressable>
          )}
        />
      )}

      {/* New chat bar */}
      <View
        style={[
          styles.inputSection,
          {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
            paddingBottom: bottomPad + 12,
          },
        ]}
      >
        {/* Persona selector */}
        <Pressable
          style={({ pressed }) => [
            styles.personaBtn,
            {
              backgroundColor: colors.muted,
              borderColor: selectedPersona.accentColor + "66",
              opacity: pressed ? 0.8 : 1,
            },
          ]}
          onPress={() => setPickerVisible(true)}
        >
          <Text style={styles.personaEmoji}>{selectedPersona.emoji}</Text>
          <Text style={[styles.personaLabel, { color: colors.foreground }]}>
            {selectedPersona.name}
          </Text>
          <Feather
            name="chevron-down"
            size={14}
            color={colors.mutedForeground}
          />
        </Pressable>

        {/* Title + send row */}
        <View style={styles.inputRow}>
          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: colors.muted,
                color: colors.foreground,
                borderColor: colors.border,
              },
            ]}
            placeholder="Chat name (optional)..."
            placeholderTextColor={colors.mutedForeground}
            value={newTitle}
            onChangeText={setNewTitle}
            returnKeyType="done"
            onSubmitEditing={handleNew}
          />
          <Pressable
            style={({ pressed }) => [
              styles.newBtn,
              {
                backgroundColor: selectedPersona.accentColor,
                opacity: pressed || creating ? 0.8 : 1,
              },
            ]}
            onPress={handleNew}
            disabled={creating}
          >
            {creating ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Feather name="plus" size={22} color="#fff" />
            )}
          </Pressable>
        </View>
      </View>

      <PersonaPicker
        visible={pickerVisible}
        selected={selectedPersona}
        onSelect={setSelectedPersona}
        onClose={() => setPickerVisible(false)}
      />
    </View>
  );
}

function makeStyles(
  colors: ReturnType<typeof useColors>,
  topPad: number,
  _bottomPad: number
) {
  return StyleSheet.create({
    container: { flex: 1 },
    header: {
      paddingTop: topPad + 16,
      paddingHorizontal: 24,
      paddingBottom: 16,
    },
    headerTop: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },
    headerTitle: {
      fontFamily: "Inter_700Bold",
      fontSize: 32,
      color: colors.foreground,
      letterSpacing: -0.5,
    },
    headerSub: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: colors.mutedForeground,
      marginTop: 2,
    },
    themeBtn: {
      width: 38,
      height: 38,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "center",
    },
    center: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      gap: 12,
    },
    emptyIcon: {
      width: 72,
      height: 72,
      borderRadius: 36,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 4,
    },
    emptyTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 18,
    },
    emptySub: {
      fontFamily: "Inter_400Regular",
      fontSize: 14,
    },
    list: { paddingHorizontal: 16, paddingTop: 4, paddingBottom: 12 },
    card: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      borderRadius: 16,
      padding: 14,
      marginBottom: 10,
    },
    cardLeft: { flexDirection: "row", alignItems: "center", flex: 1 },
    cardIcon: {
      width: 40,
      height: 40,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "center",
      marginRight: 12,
    },
    cardEmoji: { fontSize: 20 },
    cardText: { flex: 1 },
    cardTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 15,
    },
    cardMeta: {
      fontFamily: "Inter_400Regular",
      fontSize: 12,
      marginTop: 2,
    },
    deleteBtn: { padding: 6 },
    searchRow: { flexDirection: "row" },
    searchBox: {
      flex: 1,
      flexDirection: "row",
      alignItems: "center",
      height: 42,
      borderRadius: 13,
      paddingHorizontal: 12,
      borderWidth: 1,
    },
    searchInput: {
      flex: 1,
      fontFamily: "Inter_400Regular",
      fontSize: 15,
    },
    inputSection: {
      paddingHorizontal: 16,
      paddingTop: 12,
      borderTopWidth: 1,
      gap: 10,
    },
    personaBtn: {
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderRadius: 12,
      borderWidth: 1.5,
      gap: 6,
      alignSelf: "flex-start",
    },
    personaEmoji: { fontSize: 16 },
    personaLabel: {
      fontFamily: "Inter_500Medium",
      fontSize: 13,
    },
    inputRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
    },
    input: {
      flex: 1,
      height: 46,
      borderRadius: 14,
      paddingHorizontal: 14,
      fontFamily: "Inter_400Regular",
      fontSize: 15,
      borderWidth: 1,
    },
    newBtn: {
      width: 46,
      height: 46,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center",
    },
  });
}
