import React from "react";
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { PERSONAS, type Persona } from "@/constants/personas";
import { useColors } from "@/hooks/useColors";

type Props = {
  visible: boolean;
  selected: Persona;
  onSelect: (persona: Persona) => void;
  onClose: () => void;
};

export function PersonaPicker({ visible, selected, onSelect, onClose }: Props) {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <Pressable style={styles.backdrop} onPress={onClose} />
      <View
        style={[
          styles.sheet,
          {
            backgroundColor: colors.card,
            paddingBottom: insets.bottom + 16,
          },
        ]}
      >
        <View
          style={[styles.handle, { backgroundColor: colors.mutedForeground }]}
        />
        <Text style={[styles.title, { color: colors.foreground }]}>
          Choose a Persona
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Sets the AI's personality for this chat
        </Text>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.list}
        >
          {PERSONAS.map((persona) => {
            const isSelected = persona.id === selected.id;
            return (
              <Pressable
                key={persona.id}
                style={({ pressed }) => [
                  styles.card,
                  {
                    backgroundColor: isSelected
                      ? colors.secondary
                      : colors.muted,
                    borderColor: isSelected
                      ? persona.accentColor
                      : "transparent",
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                onPress={() => {
                  onSelect(persona);
                  onClose();
                }}
              >
                <View
                  style={[
                    styles.emojiContainer,
                    { backgroundColor: persona.accentColor + "22" },
                  ]}
                >
                  <Text style={styles.emoji}>{persona.emoji}</Text>
                </View>
                <View style={styles.cardText}>
                  <Text
                    style={[styles.personaName, { color: colors.foreground }]}
                  >
                    {persona.name}
                  </Text>
                  <Text
                    style={[
                      styles.tagline,
                      { color: colors.mutedForeground },
                    ]}
                  >
                    {persona.tagline}
                  </Text>
                </View>
                {isSelected && (
                  <View
                    style={[
                      styles.selectedDot,
                      { backgroundColor: persona.accentColor },
                    ]}
                  />
                )}
              </Pressable>
            );
          })}
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  sheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 12,
    paddingHorizontal: 16,
    maxHeight: "80%",
  },
  handle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 16,
    opacity: 0.4,
  },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 20,
    textAlign: "center",
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    textAlign: "center",
    marginBottom: 20,
  },
  list: { gap: 10, paddingBottom: 8 },
  card: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 16,
    padding: 14,
    borderWidth: 2,
    gap: 12,
  },
  emojiContainer: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  emoji: { fontSize: 22 },
  cardText: { flex: 1 },
  personaName: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 15,
  },
  tagline: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 2,
  },
  selectedDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
});
