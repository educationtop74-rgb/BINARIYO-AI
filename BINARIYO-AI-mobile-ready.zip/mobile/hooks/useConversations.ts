import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const BASE = `https://chat-bot-ai--educationtop74.replit.app/api`;

export type Conversation = {
  id: number;
  title: string;
  systemPrompt: string;
  personaName: string;
  createdAt: string;
};

type Message = {
  id: number;
  conversationId: number;
  role: string;
  content: string;
  createdAt: string;
};

export type ConversationWithMessages = Conversation & { messages: Message[] };

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  if (res.status === 204) return undefined as unknown as T;
  return res.json() as Promise<T>;
}

type CreateConversationInput = {
  title: string;
  systemPrompt?: string;
  personaName?: string;
};

export function useConversations() {
  const qc = useQueryClient();

  const query = useQuery<Conversation[]>({
    queryKey: ["conversations"],
    queryFn: () => apiFetch<Conversation[]>("/openai/conversations"),
  });

  const createMutation = useMutation({
    mutationFn: (input: CreateConversationInput) =>
      apiFetch<Conversation>("/openai/conversations", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["conversations"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiFetch<void>(`/openai/conversations/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["conversations"] }),
  });

  return {
    conversations: query.data ?? [],
    isLoading: query.isLoading,
    createConversation: createMutation.mutateAsync,
    deleteConversation: deleteMutation.mutateAsync,
  };
}

export function useConversation(id: number) {
  const query = useQuery<ConversationWithMessages>({
    queryKey: ["conversation", id],
    queryFn: () =>
      apiFetch<ConversationWithMessages>(`/openai/conversations/${id}`),
    enabled: !!id,
  });

  return {
    conversation: query.data,
    isLoading: query.isLoading,
  };
}
