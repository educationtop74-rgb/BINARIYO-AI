import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { useColorScheme } from "react-native";

type ThemeMode = "system" | "light" | "dark";

type ThemeContextType = {
  mode: ThemeMode;
  resolved: "light" | "dark";
  toggle: () => void;
};

const ThemeContext = createContext<ThemeContextType>({
  mode: "system",
  resolved: "light",
  toggle: () => {},
});

const STORAGE_KEY = "@theme_mode";

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme() ?? "light";
  const [mode, setMode] = useState<ThemeMode>("system");

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((stored) => {
      if (stored === "light" || stored === "dark" || stored === "system") {
        setMode(stored);
      }
    });
  }, []);

  const toggle = useCallback(() => {
    setMode((prev) => {
      const next =
        prev === "system"
          ? system === "dark"
            ? "light"
            : "dark"
          : prev === "dark"
          ? "light"
          : "dark";
      AsyncStorage.setItem(STORAGE_KEY, next);
      return next;
    });
  }, [system]);

  const resolved: "light" | "dark" = mode === "system" ? system : mode;

  return (
    <ThemeContext.Provider value={{ mode, resolved, toggle }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
