const colors = {
  light: {
    text: "#0f0f0f",
    tint: "#6C63FF",

    background: "#F7F7F9",
    foreground: "#0f0f0f",

    card: "#FFFFFF",
    cardForeground: "#0f0f0f",

    primary: "#6C63FF",
    primaryForeground: "#FFFFFF",

    secondary: "#EFEFFF",
    secondaryForeground: "#3730A3",

    muted: "#F0F0F5",
    mutedForeground: "#8888A4",

    accent: "#EDE9FE",
    accentForeground: "#5B21B6",

    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    border: "#E5E5EF",
    input: "#E5E5EF",

    userBubble: "#6C63FF",
    userBubbleText: "#FFFFFF",
    aiBubble: "#FFFFFF",
    aiBubbleText: "#0f0f0f",

    surface: "#FFFFFF",
    surfaceBorder: "#EBEBF3",
  },

  dark: {
    text: "#F0F0FF",
    tint: "#7C6FFF",

    background: "#0D0D14",
    foreground: "#F0F0FF",

    card: "#16161F",
    cardForeground: "#F0F0FF",

    primary: "#7C6FFF",
    primaryForeground: "#FFFFFF",

    secondary: "#1E1B3A",
    secondaryForeground: "#A5B4FC",

    muted: "#1A1A28",
    mutedForeground: "#7070A0",

    accent: "#2D2458",
    accentForeground: "#C4B5FD",

    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    border: "#2A2A3E",
    input: "#2A2A3E",

    userBubble: "#7C6FFF",
    userBubbleText: "#FFFFFF",
    aiBubble: "#1E1E2E",
    aiBubbleText: "#F0F0FF",

    surface: "#16161F",
    surfaceBorder: "#2A2A3E",
  },

  radius: 16,
};

export default colors;
